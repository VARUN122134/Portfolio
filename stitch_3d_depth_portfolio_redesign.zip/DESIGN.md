---
name: Cosmic Embedded
colors:
  surface: '#131318'
  surface-dim: '#131318'
  surface-bright: '#39383e'
  surface-container-lowest: '#0e0e13'
  surface-container-low: '#1b1b20'
  surface-container: '#1f1f25'
  surface-container-high: '#2a292f'
  surface-container-highest: '#35343a'
  on-surface: '#e4e1e9'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#e4e1e9'
  inverse-on-surface: '#303036'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#ffb783'
  on-tertiary: '#4f2500'
  tertiary-container: '#d97721'
  on-tertiary-container: '#452000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#703700'
  background: '#131318'
  on-background: '#e4e1e9'
  surface-variant: '#35343a'
  neon-indigo: '#6366f1'
  electric-violet: '#a855f7'
  surface-glass: rgba(255, 255, 255, 0.03)
  text-primary: '#ffffff'
  text-secondary: '#e0e0e0'
  text-muted: '#888888'
  glow-indigo: rgba(99, 102, 241, 0.4)
typography:
  hero-title:
    fontFamily: Inter
    fontSize: 96px
    fontWeight: '900'
    lineHeight: '1.05'
    letterSpacing: -0.04em
  hero-title-mobile:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '900'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  section-title:
    fontFamily: Inter
    fontSize: 44px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  card-title:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: '1.8'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
  nav-link:
    fontFamily: Inter
    fontSize: 13.5px
    fontWeight: '500'
    lineHeight: '1'
  section-label:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.25em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  section-gap-desktop: 100px
  section-gap-mobile: 80px
  gutter: 24px
  container-max-width: 1200px
  card-padding: 32px
---

## Brand & Style

This design system targets the intersection of high-level Artificial Intelligence and low-level Hardware Engineering. The brand personality is technical, futuristic, and highly precise—evoking the feeling of a sophisticated command center or a neural network firing in deep space.

The aesthetic follows a **Glassmorphism** approach set against a high-contrast **Minimalist** foundation. It uses translucent layers, vibrant background blurs, and neon accents to suggest depth and modern innovation. The user's photo should be integrated into the hero section with a subtle desaturation or dark-tinted overlay to ensure it feels cohesive with the "Deep Space" environment, allowing the neon gradients to wrap around the subject.

## Colors

The palette is rooted in a "Deep Space" black (`#0a0a0f`), providing a canvas for high-energy neon accents. 

- **Primary & Secondary:** A gradient transition from Neon Indigo to Electric Violet represents the flow of data and neural activity.
- **Glass Surfaces:** Containers use extremely low-opacity white backgrounds with a backdrop-blur effect to create a layered, translucent feel without cluttering the dark UI.
- **Typography Contrast:** Pure white is reserved for headings and interactive elements, while a slightly dimmed grey-white is used for long-form body text to reduce eye strain in the dark environment.

## Typography

This system uses **Inter** exclusively to lean into a systematic, utilitarian, and clean developer aesthetic. The hierarchy is driven by extreme weight contrasts—moving from ultra-bold 900-weight hero titles to light-weight secondary body text.

- **Display Text:** Uses tight letter-spacing and massive scale to create impact.
- **Metadata:** Smaller labels use wide letter-spacing and uppercase styling to evoke "serial numbers" or technical specifications.
- **Accessibility:** Ensure line height for body text remains generous (1.8) to maintain readability against the dark background.

## Layout & Spacing

The layout utilizes a **Fixed Grid** system centered on a 1200px max-width container for desktop. A 12-column grid provides the structure for project and resume cards, typically spanning 4 or 6 columns each.

- **Vertical Rhythm:** Large vertical gaps (100px) between sections allow the background Three.js animations or "Deep Space" gradients to breathe.
- **Mobile Adaptation:** On mobile, margins reduce to 24px and section gaps to 80px. Grid columns collapse into a single-column stack to prioritize readability and tap-targets.
- **Consistency:** All spacing values are multiples of 4px or 8px to maintain a strict mathematical rhythm.

## Elevation & Depth

Depth is established through **Tonal Layers** and **Glassmorphism** rather than traditional shadows.

- **Z-Index Strategy:** The background layer features a dynamic "Three.js" starfield or geometric mesh. The content floats above this on "Glass" surfaces.
- **Glass Effect:** Use `backdrop-filter: blur(12px)` and a subtle `1px solid rgba(255,255,255,0.06)` border to define card boundaries.
- **Interaction Depth:** On hover, cards should lift (`translateY(-6px)`) and the border-color should transition to the Primary Indigo to simulate the element "powering on."
- **Glows:** Use `box-shadow` with high blur and low opacity tinted with the primary color to create an ambient neon glow around active components.

## Shapes

The design uses a **Rounded** shape language to balance the technical "hardness" of the AI niche with a modern, premium feel. 

- **Cards:** Use `14px` to `20px` radii for larger surfaces like project cards and resume containers.
- **Buttons & Tags:** Use pill-shaped roundedness (`20px`+) for smaller interactive elements like tech tags to distinguish them from structural cards.
- **Inputs:** Maintain a consistent `10px` radius for form fields to provide a clear, modern appearance.

## Components

### Buttons
- **Primary:** Gradient background (Indigo to Violet), bold text, and a `0 8px 30px` indigo glow on hover.
- **Secondary:** Transparent background with a `1px solid #333` border, transitioning to a primary border on hover.

### Cards
- **Project Cards:** Glassmorphic background, subtle border, and a 0.4s hover transition that scales the card and intensifies the glow.
- **Resume Cards:** Structured with clear vertical lines and "Section Labels" as headers. High padding (50px 40px) for a premium editorial feel.

### Form Fields
- Dark, translucent backgrounds (`rgba(255,255,255,0.04)`) with a `1px` border that glows Indigo when focused.

### Tech Tags
- Pill-shaped, small uppercase typography, with a subtle indigo background tint (`rgba(99,102,241,0.12)`).

### Navigation
- Sticky top bar with a strong backdrop blur and a thin bottom border to separate it from the main content.